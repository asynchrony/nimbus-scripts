module EndpointsHelper
end
