class Endpoint < ApplicationRecord
end
