class EndpointsController < ApplicationController
  def index
    endpoints = Endpoint.all
    render plain: endpoints.to_json
  end
end
