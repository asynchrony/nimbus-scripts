# [Trello Board](https://trello.com/b/MvJyBWZz), <https://trello.com/b/MvJyBWZz>

# [Cisco CloudCenter Sandbox](https://c3-ccm-asl.sandbox.wwtatc.local/), <https://c3-ccm-asl.sandbox.wwtatc.local/>

- Email: admin@wwtatc.com
- Password: ASLasl1!
- Tenant ID: (blank)

# [gitlab docker executor](https://docs.gitlab.com/runner/executors/docker.html), <https://docs.gitlab.com/runner/executors/docker.html>

[![build status](https://gitlab.asynchrony.com/kyle.pointer/nimbus/badges/master/build.svg)](https://gitlab.asynchrony.com/kyle.pointer/nimbus/commits/master)
