Rails.application.routes.draw do
  resources :endpoints, only: [:index]
end
