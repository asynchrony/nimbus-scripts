Endpoint.create(name: 'p1', displayName: 'Param 1')
Endpoint.create(name: 'p2', displayName: 'Param 2')
